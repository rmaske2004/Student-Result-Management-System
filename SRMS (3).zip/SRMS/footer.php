<!-- footer.php -->
<footer style="">
    <div>
        <p>&copy;<?php echo date("Y"); ?> SRMS Portal. All rights reserved.</p>
        <p>Designed With❤️ By AGS & RRM </p>
    </div>
</footer>
